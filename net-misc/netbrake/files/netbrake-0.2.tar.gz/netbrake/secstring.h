#ifndef __SEC_STRING_H
#define __SEC_STRING_H

size_t strlcat(char *dst, const char *src, size_t siz);
size_t strlcpy(char *dst, const char *src, size_t siz);
void sec_snprintf(char *str, size_t size, const char *format, ...);
void sec_snprintf_cat(char *str, size_t size, const char *format, ...);

#endif /* __SEC_STRING_H */
